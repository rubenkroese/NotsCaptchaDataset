# Polygon Captcha Solver > 2023-04-04 10:17am
https://universe.roboflow.com/nots-project/polygon-captcha-solver

Provided by a Roboflow user
License: CC BY 4.0

