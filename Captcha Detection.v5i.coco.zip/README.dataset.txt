# Captcha Detection > 2023-03-21 9:22am
https://universe.roboflow.com/nots-project/captcha-detection-2fuvn

Provided by a Roboflow user
License: CC BY 4.0

